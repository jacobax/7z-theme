# 7-Zip macOS 风格美化（自制）

目标版本：**7-Zip 26.03 (x64)**，安装目录 `C:\Program Files\7-Zip`
状态：**已生成并验证渲染，尚未安装**。看过 `preview\` 里的预览图后再决定。

---

## 设计

### 文件图标（`7z.dll`，27 种格式）

macOS「Liquid Glass / Big Sur」取向的圆角方形 App 图标：

* **squircle** 连续圆角（超椭圆 n=5 逼近 Apple 的连续曲率，不是普通圆角矩形）
* 竖向渐变底色（顶部提亮 26% → 底部压暗 12%，中间有过渡节点）
* **玻璃高光**：从顶部向下淡出的白色纱层，加一圈内侧亮边
* 底部内侧轻微压暗，增强体积感
* **柔和投影**：对 squircle 蒙版做两次盒式模糊（近似高斯），偏移 2.2% 高度、透明度 30%
* 中央**白色格式文字**（`Segoe UI Semibold`，自动缩放至宽度 70% 以内）
  * 亮底色（如黄 `#FFD60A`）自动改用深色字 `#1C1C1E` 保证对比度
* **16/20/24px 不放文字**（那样只会糊成一团），改画「堆叠层」标记，小尺寸下依然锐利

27 种格式各配一个 macOS 系统色：

    #007AFF 蓝      #5856D6 靛      #00C7BE 青绿    #AF52DE 紫
    #A2845E 棕      #8E8E93 灰      #34C759 绿      #FF9500 橙
    #32ADE6 天蓝    #5E5CE6 蓝紫    #FF3B30 红      #FF2D55 玫红
    #FFB340 琥珀    #B08968 浅棕    #30D158 亮绿    #64D2FF 淡蓝
    #BF5AF2 紫罗兰  #FF6482 粉      #AC8E68 棕灰    #0A84FF 蓝
    #5AC8FA 水蓝    #FFD60A 黄      #FF9F0A 橙      #40C8E0 青
    #7D7AFF 蓝紫    #FF375F 绯红    #00A3FF 蔚蓝

每个 `.ico` 含 8 个尺寸：**256(PNG) + 64/48/40/32/24/20/16(32bpp DIB + AND 掩码)**。

### 工具栏图标（`7zFM.exe`，7 个按钮）— 两套

| 按钮 | 图形 | 单色 | 彩色 |
|---|---|---|---|
| Add | 加号 | `#3A3A3C` | 绿 `#34C759` |
| Extract | 下箭头 + 托盘 | 同上 | 蓝 `#007AFF` |
| Test | 放大镜 + 对勾 | 同上 | 橙 `#FF9F0A` |
| Copy | 两张错位纸张 | 同上 | 靛 `#5856D6` |
| Move | 纸张 + 右箭头 | 同上 | 紫 `#AF52DE` |
| Delete | 垃圾桶 | 同上 | 红 `#FF3B30` |
| Info | 圆圈 i | 同上 | 灰 `#8E8E93` |

* **单色线性**：SF Symbols 风格，圆头圆角描边（48x36 用 3.5px，24x24 用 1.75px），无底板 —— 最接近 macOS 工具栏观感
* **彩色**：同一套图形配 macOS 系统色，下面垫一层 10% 透明度的圆角底板

两套都是 **32bpp + alpha 通道**注入，边缘抗锯齿完整保留（不是 1-bit 遮罩的硬边）。
实机验证 0 个洋红像素，透明区域正确。

---

## 目录

    patched\7z.dll              27 个 macOS 文件图标（两套工具栏共用）
    patched\mono\7zFM.exe       单色线性工具栏
    patched\colored\7zFM.exe    彩色工具栏
    original\                   官方 26.03 原版（还原用）
    assets\filetype-ico\        27 个 .ico 源文件
    assets\toolbar-mono\        14 个 BMP(带 alpha) + 14 个 PNG 预览
    assets\toolbar-colored\     同上
    preview\                    预览图
    build\                      生成脚本（MacIcons.cs / GenMac.ps1 / BuildMac.ps1 / Patcher.cs）
    apply.ps1 / restore.ps1

## 预览

* `preview\01-文件图标-全格式.png` — 27 种格式 × 6 个尺寸的总览
* `preview\02-文件图标-256px示例.png` — 8 种常见格式的 256px 大图
* `preview\工具栏-单色线性.png` / `工具栏-彩色.png` — 7 个按钮 × 两种尺寸
* `preview\icons\*.png` — 每个格式单独的 256px 图
* `preview\05-实机渲染-*.png` — **7-Zip 里真实渲染出来的效果**（沙箱，未安装）

## 怎么应用

    # 管理员权限 PowerShell
    cd C:\Users\Administrator\Desktop\7-Zip-macOS主题
    pwsh -File .\apply.ps1 -Style mono        # 或 -Style colored

还原官方原版：

    pwsh -File .\restore.ps1

## 哈希

    原版 7z.dll     1906688 B  65E4C1F855F9EF6E8F0F5DF8E3F27D9EB5F07311408639DA0A1CA0B8F4871B0D
    原版 7zFM.exe   1003520 B  7F7067B2264FBF8CBD1348CF7F41A0E35C928DE750D53533C963EBE334DBD612
    macOS 7z.dll    3348992 B  01DB485B8F4A31681A2C0B0AFEF128C06D3E498545B85E42280C57495FE8D7E9
    mono 7zFM.exe   1058816 B  AB3793699A370E58AB63FDFC57C8FF9681F260358DAA33CAA536FCF6702BBAAA
    colored 7zFM.exe 1058816 B 9EA8DB2865C971BA40BC6C93DBE892B3242906BBEED863B2B7F3C9DD5AD91559

## 已验证

1. 27 个 `.ico` 结构有效，各含 8 个尺寸条目，无越界
2. 14 个工具栏 BMP：尺寸正确、32bpp、带 alpha
3. 注入后实机启动 7-Zip 截图：**两套样式均 0 个洋红像素**，透明与抗锯齿正常
4. 图标组映射沿用此前逐图 SHA256 验证过的 0..26 ↔ 7z/zip/…/zst 对应关系

## 重新生成 / 改配色

`build\GenMac.ps1` 顶部的 `Labels` / `Accents`（文件图标）和 `TbColors`（工具栏）改完重跑即可。
注意 `GenMac.ps1` 依赖 `System.Drawing`，要用 **Windows PowerShell 5.1** 跑：

    powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build\GenMac.ps1

（PowerShell 7 下 `Add-Type -Path` 的默认引用集不含 `System.Drawing.Common`，会编译失败。）

## 注意

* 写入 `C:\Program Files\7-Zip` 需要管理员权限，操作前需关闭 7-Zip。
* 7-Zip 官方不支持主题，**每次升级都会覆盖回原版**，升级后重跑 `apply.ps1`。
* 7-Zip 没有深色模式，图标是按浅色工具栏底色（`#F0F0F0`）配的。
