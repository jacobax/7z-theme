# 7-Zip Windows 11 风格美化（自制）

目标版本：**7-Zip 26.03 (x64)**，安装目录 `C:\Program Files\7-Zip`
状态：**已生成并验证渲染，尚未安装**。看过 `preview\` 后再决定。

---

## 设计

### 文件图标（`7z.dll`，27 种格式）

Windows 11 / Fluent Design 的**文档纸张**样式，和 macOS 那套的圆角方形 App 图标明确区分：

* **纸张**：白色竖向圆角矩形（宽 0.68、高 0.88 画布），轻微竖向渐变（纯白 → `#F3F3F7`）
* **右上折角**：切角 + 折回三角，配 `#E9E9F0 → #D6D6E0` 渐变和细描边（16px 时省略，避免糊）
* **发丝边框** `#DADAE3`
* **柔和投影**：对纸张路径做两次盒式模糊（近似高斯），偏移 2% 高度、26% 不透明度
* **彩色格式色带**：纸张下部一块圆角色带，带自身渐变，内含白色格式文字
  * 亮底色（如金 `#C19C00`）自动改用深色字保证对比度
* **16/20/24px 不放文字**（会糊），只保留纸张 + 色带，靠颜色区分类型

27 种格式各配一个 Windows 11 / WinUI 强调色：

    #0067C0 蓝      #0078D4 蓝      #038387 青绿    #8764B8 紫
    #8E562E 棕      #69797E 灰      #107C10 绿      #CA5010 橙
    #0F6CBD 蓝      #4F6BED 靛      #C42B1C 红      #E3008C 品红
    #EF6950 珊瑚    #8A6F4E 棕      #0B6A0B 深绿    #2B88D8 天蓝
    #744DA9 紫罗兰  #E74856 玫红    #9A7B4F 棕      #0078D4 蓝
    #00B7C3 青      #C19C00 金      #D83B01 橙      #00B294 青绿
    #6B69D6 靛      #C50F1F 绯红    #0F6CBD 蔚蓝

每个 `.ico` 含 8 个尺寸：**256(PNG) + 64/48/40/32/24/20/16(32bpp DIB + AND 掩码)**。

### 工具栏图标（`7zFM.exe`，7 个按钮）— 两套

| 按钮 | Fluent 图形 | 单色 | 彩色 |
|---|---|---|---|
| Add | 加号 | `#1C1C1C` 87% | 绿 `#107C10` |
| Extract | **下载箭头**（箭头 + 基线，不是托盘） | 同上 | 蓝 `#0078D4` |
| Test | 放大镜 + 对勾 | 同上 | 青绿 `#038387` |
| Copy | 两张错位纸张（后张画成 L 形缺口） | 同上 | 靛 `#4F6BED` |
| Move | 纸张 + 右向箭头 | 同上 | 紫 `#8764B8` |
| Delete | **垃圾桶（无桶箍）** | 同上 | 红 `#C42B1C` |
| Info | 圆圈 i | 同上 | 灰 `#605E5C` |

* **单色线性**：Fluent outline 风格，描边 **1.45u**（比 macOS/SF Symbols 那套的 1.75u 明显更细），
  颜色用 Win11 的 `TextFillColorPrimary`（#1C1C1C @ 87%）—— 最接近 Win11 命令栏观感
* **彩色**：同一套 Fluent 图形配 Win11 强调色，**无底板**（macOS 那套有底板，这是两者的区分点）

两套都是 **32bpp + alpha 通道**注入，抗锯齿完整保留。实机验证 0 个洋红像素。

---

## 目录

    patched\7z.dll              27 个 Win11 文件图标（两套工具栏共用）
    patched\mono\7zFM.exe       Fluent 单色线性工具栏
    patched\colored\7zFM.exe    Win11 强调色工具栏
    original\                   官方 26.03 原版（还原用）
    assets\filetype-ico\        27 个 .ico 源文件
    assets\toolbar-mono\        14 个 BMP(带 alpha) + 14 个 PNG 预览
    assets\toolbar-colored\     同上
    preview\                    预览图
    build\                      生成脚本（WinIcons.cs / MacIcons.cs / GenWin.ps1 / BuildWin.ps1 / Patcher.cs）
    apply.ps1 / restore.ps1

## 预览

* `preview\01-文件图标-全格式.png` — 27 种格式 × 6 个尺寸总览
* `preview\02-文件图标-256px示例.png` — 8 种常见格式的 256px 大图
* `preview\工具栏-单色线性.png` / `工具栏-彩色.png` — 7 个按钮 × 两种尺寸，垫在真实底色 `#F0F0F0` 上
* `preview\icons\*.png` — 每个格式单独的 256px 图
* `preview\05-实机渲染-*.png` — **7-Zip 里真实渲染出来的效果**（沙箱，未安装）

## 怎么应用

    # 管理员权限 PowerShell
    cd C:\Users\Administrator\Desktop\7-Zip-Win11主题
    pwsh -File .\apply.ps1 -Style mono        # 或 -Style colored

还原官方原版：

    pwsh -File .\restore.ps1

## 哈希

    原版 7z.dll      1906688 B  65E4C1F855F9EF6E8F0F5DF8E3F27D9EB5F07311408639DA0A1CA0B8F4871B0D
    原版 7zFM.exe    1003520 B  7F7067B2264FBF8CBD1348CF7F41A0E35C928DE750D53533C963EBE334DBD612
    Win11 7z.dll     3153920 B  1E812AB33B498255B6C97BDBD8DA036FD5E523DE089BA65F5A15D276BE926A3B
    mono 7zFM.exe    1058816 B  1E9B3ACB679E05D4F40CA5DD1F180F32E0A9D3B3E585A1564595D1ACB96A1B1A
    colored 7zFM.exe 1058816 B  A3F25A1157C3E7B47989A0309B21C3CE94BC575B5037368523358126471F3F2C

## 已验证

1. 27 个 `.ico` 结构有效，各含 8 个尺寸条目
2. 14 个工具栏 BMP：尺寸正确、32bpp、带 alpha
3. 注入后实机启动 7-Zip 截图：**两套样式均 0 个洋红像素**，透明与抗锯齿正常
4. 图标组映射沿用此前逐图 SHA256 验证过的 0..26 ↔ 7z/zip/…/zst 对应关系

## 重新生成 / 改配色

`build\GenWin.ps1` 顶部的 `Labels` / `Accents`（文件图标）和 `TbColors`（工具栏）改完重跑即可。
必须用 **Windows PowerShell 5.1** 跑：

    powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build\GenWin.ps1

（PowerShell 7 下 `Add-Type -Path` 的默认引用集不含 `System.Drawing.Common`，会编译失败。）

`WinIcons.cs` 复用了 `MacIcons.cs` 里的 ICO / DIB 写入器，两个文件要一起编译。

## 注意

* 写入 `C:\Program Files\7-Zip` 需要管理员权限，操作前需关闭 7-Zip。
* 7-Zip 官方不支持主题，**每次升级都会覆盖回原版**，升级后重跑 `apply.ps1`。
* 7-Zip 没有深色模式，图标是按浅色工具栏底色（`#F0F0F0`）配的。
