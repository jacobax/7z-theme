# 应用 Windows 11 主题到 7-Zip
# 用法:  pwsh -File .\apply.ps1 -Style mono        (Fluent 单色线性工具栏)
#        pwsh -File .\apply.ps1 -Style colored     (Win11 强调色工具栏)
param(
  [ValidateSet('mono','colored')][string]$Style = 'mono',
  [string]$Dir = 'C:\Program Files\7-Zip'
)
$ErrorActionPreference = 'Stop'
Get-Process 7zFM,7zG,7z -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 300
Copy-Item (Join-Path $PSScriptRoot 'patched\7z.dll')          (Join-Path $Dir '7z.dll')   -Force
Copy-Item (Join-Path $PSScriptRoot "patched\$Style\7zFM.exe") (Join-Path $Dir '7zFM.exe') -Force
Write-Output "已应用 Windows 11 主题（工具栏样式: $Style）"
Get-ChildItem (Join-Path $Dir '7z.dll'),(Join-Path $Dir '7zFM.exe') | ForEach-Object {
  Write-Output ("  {0,-10} {1}" -f $_.Name, (Get-FileHash $_.FullName -Algorithm SHA256).Hash)
}
