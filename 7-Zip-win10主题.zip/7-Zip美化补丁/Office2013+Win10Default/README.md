# 7-Zip 美化：RipplePiam/7zip-Theme（Windows 10 Default + Office 2013）

## 做了什么

用 https://github.com/RipplePiam/7zip-Theme 的资源美化本机 7-Zip 26.03 (x64)：

| 目标 | 资源 | 来源 |
|---|---|---|
| 文件类型图标 | `7z.dll` 里 27 个 `RT_GROUP_ICON` | `Filetype/Windows 10 Default by_d93yxyk/*.ico` |
| 工具栏图标 | `7zFM.exe` 里 14 个 `RT_BITMAP` | `Toolbar/Office 2013_by_d93yyju/{48x36,24x24}/*.bmp` |

仓库只提供「Windows 10 Default 文件图标 + Glyfz 2016 工具栏」的**成品补丁**，且版本最高只到 7z2501。
本机是 26.03，且要的 Office 2013 工具栏**没有任何成品补丁**，所以这两个文件是**按仓库补丁的构造方式自行生成**的。

## 补丁构造方式（逆向自仓库成品补丁）

* `7z.dll`：每个图标组换成对应 `.ico` 里的 8 张图（256 PNG + 64/48/40/32/24/20/16 DIB）。
  组名保持原样：组 `"0"` 是**字符串名**（=7z），组 `1..26` 是序号（zip/bz2/rar/arj/z/lzh/cab/iso/001/rpm/deb/cpio/tar/gz/wim/lzma/dmg/hfs/xar/vhd/fat/ntfs/xz/squashfs/apfs/zst）。
  旧的 56 个 `RT_ICON` 已删除，新增 216 个。
* `7zFM.exe`：14 个位图 = `100..106`(48x36 大按钮) 与 `150..156`(24x24 普通按钮)，对应 Add/Extract/Test/Copy/Move/Delete/Info。
  7-Zip 源码 `App.cpp` 用 `imageList.Create(..., ILC_MASK|ILC_COLOR32, ...)` + `AddMasked(bmp, RGB(255,0,255))`，
  即**洋红 = 透明遮罩色**，所以位图写成 8bpp 索引格式、**调色板索引 0 = #FF00FF**。

为什么是 8bpp：仓库作者用的是 4bpp（只够 15 色，Delete/Move 等图标会被量化失真）。
8bpp 有 255 色可用，实测 14 张图全部命中**精确调色板（无损）**，同时保留 1-bit 洋红遮罩这一已被验证可靠的透明机制。
（试过 32bpp + alpha：`AddMasked` 对 32bpp 位图不生效，洋红会直接显示出来，故不可用。）

## 文件

    original/     官方 26.03 原版 7z.dll / 7zFM.exe
    themed/       美化后的 7z.dll / 7zFM.exe（= 当前已安装的版本）
    restore.ps1   还原到官方原版（两个文件一起还原，带哈希校验）
    apply.ps1     7-Zip 升级覆盖后重新应用美化
    build/        生成脚本与素材（Patcher.cs / Build.ps1 / ResDump2.ps1 / Shot.ps1 + 图标源文件）

## 哈希

    原版 7z.dll    1906688 B  65E4C1F855F9EF6E8F0F5DF8E3F27D9EB5F07311408639DA0A1CA0B8F4871B0D
    原版 7zFM.exe  1003520 B  7F7067B2264FBF8CBD1348CF7F41A0E35C928DE750D53533C963EBE334DBD612
    美化 7z.dll    3478016 B  D536752B2E766F479CD2464C05E51088EA82D25E6026DD1A71F4E54DB0B929A4
    美化 7zFM.exe  1025024 B  2C0429B494AEC46548B7982FC8F54F9CC2B31ACA91CE0F4D751E168818917D99

## 已验证

1. 资源结构：27 个图标组各 8 张图（组 `"0"` 字符串名保留）；14 个位图尺寸/格式正确；MENU/DIALOG/STRING/VERSION/MANIFEST 等未受影响。
2. 图标映射：逐图 SHA256 比对，确认组 1..26 ↔ zip/bz2/…/zst 与预期一致。
3. 格式正确性：用同一转换器复现仓库作者已发布的 Glyfz 2016 补丁，14 张中 13 张**渲染像素完全一致**（另 1 张 3 像素差异，源于仓库 zip 内源图与作者当时所用版本的微差）。
4. 位图无损：14 张图往返解码，opaque/transparent 误配 0，误差 0。
5. 实机运行截图：工具栏 0 个洋红像素（透明遮罩生效）；与源图对齐后误差仅剩抗锯齿边缘。
6. 图标提取：从美化后的 7z.dll 取出索引 0 的 256x256 图标，与 `7z.ico` 的 256 图**逐像素一致**。
7. `7z.exe i` 正常，7-Zip 功能未受影响。

## 注意

* 写入 `C:\Program Files\7-Zip` 需要管理员权限。
* 操作前需关闭 7-Zip 文件管理器（脚本会自动结束）。
* 7-Zip 官方不支持主题，**每次升级都会覆盖回原版**，升级后跑一次 `apply.ps1` 即可。
* 本目录的上一级还放着**另一套方案**（Segoe MDL2 字形渲染的 Fluent 图标，只改 7zFM.exe、不改 7z.dll）。
  它的 `restore-7zip-icons.ps1` **只还原 7zFM.exe**，在当前状态下运行会得到
  「新文件图标 + 旧工具栏」的混合状态；请用本目录的 `restore.ps1`。
