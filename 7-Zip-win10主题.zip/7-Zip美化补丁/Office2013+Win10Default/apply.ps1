# 重新应用 RipplePiam/7zip-Theme 主题（7-Zip 升级覆盖掉之后用这个恢复）
# 用法:  pwsh -File .\apply.ps1
param([string]$Dir = 'C:\Program Files\7-Zip')
$ErrorActionPreference = 'Stop'

Get-Process 7zFM,7zG,7z -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 300

foreach ($f in '7z.dll','7zFM.exe') {
  $src = Join-Path $PSScriptRoot "themed\$f"
  if (-not (Test-Path $src)) { throw "缺少主题文件: $src" }
  Copy-Item $src (Join-Path $Dir $f) -Force
  "  $f  已应用  $((Get-FileHash (Join-Path $Dir $f) -Algorithm SHA256).Hash)"
}
