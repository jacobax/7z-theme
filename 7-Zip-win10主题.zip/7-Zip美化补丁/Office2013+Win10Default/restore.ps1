# 还原 7-Zip 到官方 26.03 原版（同时还原 7z.dll 与 7zFM.exe）
# 用法:  pwsh -File .\restore.ps1
param([string]$Dir = 'C:\Program Files\7-Zip')
$ErrorActionPreference = 'Stop'

$want = @{
  '7z.dll'   = '65E4C1F855F9EF6E8F0F5DF8E3F27D9EB5F07311408639DA0A1CA0B8F4871B0D'
  '7zFM.exe' = '7F7067B2264FBF8CBD1348CF7F41A0E35C928DE750D53533C963EBE334DBD612'
}

Get-Process 7zFM,7zG,7z -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 300

foreach ($f in '7z.dll','7zFM.exe') {
  $src = Join-Path $PSScriptRoot "original\$f"
  if (-not (Test-Path $src)) { throw "缺少备份文件: $src" }
  $h = (Get-FileHash $src -Algorithm SHA256).Hash
  if ($h -ne $want[$f]) {
    throw "备份文件 $f 的哈希与记录的官方原版不符，拒绝写入。`n  期望: $($want[$f])`n  实际: $h"
  }
  Copy-Item $src (Join-Path $Dir $f) -Force
  $now = (Get-FileHash (Join-Path $Dir $f) -Algorithm SHA256).Hash
  if ($now -eq $h) { "  $f  已还原（哈希校验通过）" } else { "  $f  写入后哈希不符！" }
}
