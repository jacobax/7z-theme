# 7-Zip 美化补丁包

美化来源：https://github.com/RipplePiam/7zip-Theme
目标版本：**7-Zip 26.03 (x64)**，安装目录 `C:\Program Files\7-Zip`

本机当前已安装的就是 `Office2013+Win10Default` 这一套。

---

## 目录

    7-Zip美化补丁/
    ├─ Office2013+Win10Default/     ← 已在本机应用的美化
    │   ├─ original/                官方 26.03 原版 7z.dll / 7zFM.exe
    │   ├─ themed/                  美化后的成品（可直接覆盖使用）
    │   ├─ apply.ps1                应用美化
    │   ├─ restore.ps1              还原官方原版（带哈希校验）
    │   └─ README.md                详细说明与验证记录
    └─ build/                       生成工具与素材
        ├─ Patcher.cs               资源注入器（PE RT_ICON / RT_BITMAP 重建）
        ├─ Build.ps1                一键生成脚本
        ├─ ResDump2.ps1             资源枚举/对比工具
        ├─ Shot.ps1                 截图工具
        ├─ source-toolbar-bmp/      工具栏源图（Office 2013 + Windows 10 Default）
        └─ source-filetype-ico/     文件图标源图（Windows 10 Default，38 个 .ico）

---

## 怎么用

### 换到另一台机器（同为 7-Zip 26.03 x64）

以管理员身份运行 PowerShell：

    cd Office2013+Win10Default
    pwsh -File .\apply.ps1

脚本会先结束正在运行的 7-Zip，再把 `themed\` 里的两个文件复制过去。

### 还原成官方原版

    pwsh -File .\restore.ps1

会校验备份文件的 SHA256 再写入，不匹配就拒绝执行。

### 7-Zip 升级之后

升级会覆盖回原版，重跑一次 `apply.ps1` 即可。

---

## 哈希

    原版 7z.dll    1906688 B  65E4C1F855F9EF6E8F0F5DF8E3F27D9EB5F07311408639DA0A1CA0B8F4871B0D
    原版 7zFM.exe  1003520 B  7F7067B2264FBF8CBD1348CF7F41A0E35C928DE750D53533C963EBE334DBD612
    美化 7z.dll    3478016 B  D536752B2E766F479CD2464C05E51088EA82D25E6026DD1A71F4E54DB0B929A4
    美化 7zFM.exe  1025024 B  2C0429B494AEC46548B7982FC8F54F9CC2B31ACA91CE0F4D751E168818917D99

---

## 重要：为什么是自己生成的补丁

仓库只提供「Windows 10 Default 文件图标 + Glyfz 2016 工具栏」的**成品补丁**，
且版本最高只到 `7z2501`。而 26.03 的补丁、以及 Office 2013 工具栏的补丁，
**仓库里都没有**，所以这两个文件是按仓库补丁的构造方式自行生成的：

* `7z.dll`：27 个 `RT_GROUP_ICON` 换成对应 `.ico` 的 8 张图
  （256 PNG + 64/48/40/32/24/20/16）。组 `"0"` 是字符串名（=7z），组 `1..26` 是序号。
* `7zFM.exe`：14 个 `RT_BITMAP`（`100..106` = 48x36 大按钮，`150..156` = 24x24 普通按钮）。
  7-Zip 源码 `App.cpp` 用 `imageList.Create(..., ILC_MASK|ILC_COLOR32, ...)` +
  `AddMasked(bmp, RGB(255,0,255))`，即**洋红 = 透明遮罩色**，所以位图调色板索引 0 = `#FF00FF`。

用了 **8bpp** 而不是作者的 4bpp：4bpp 只有 15 色，`Delete`/`Move` 等图标会被量化失真；
8bpp 有 255 色，实测 14 张图全部命中精确调色板（无损），同时保留同一个 1-bit 洋红遮罩机制。

（32bpp + alpha 不可用：`AddMasked` 对 32bpp 位图不生效，洋红会直接显示出来。）

---

## 验证记录

1. 资源结构：27 组 × 8 图，组 `"0"` 字符串名保留；14 个位图尺寸格式正确；其他资源类型未受影响
2. 图标映射：逐图 SHA256 比对，组 `1..26` ↔ zip/bz2/…/zst 与预期一致
3. 格式正确性：用同一转换器复现作者已发布的 Glyfz 补丁，14 张中 13 张渲染像素完全一致
4. 位图无损：14 张往返解码，误配 0、误差 0
5. 实机截图：小按钮/大按钮模式均 0 个洋红像素
6. 图标提取：美化后 7z.dll 的索引 0 图标与 `7z.ico` 的 256 图逐像素一致
7. `7z.exe i` 正常，功能未受影响
